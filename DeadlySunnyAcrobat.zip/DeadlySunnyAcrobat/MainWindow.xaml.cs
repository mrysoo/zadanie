
using System.Windows;
using Microsoft.EntityFrameworkCore;
using MosaicApp.Data;
using MosaicApp.Models;
using MosaicApp.Windows;

namespace MosaicApp
{
    public partial class MainWindow : Window
    {
        private MosaicDbContext _context;
        
        public MainWindow()
        {
            InitializeComponent();
            _context = new MosaicDbContext();
            LoadData();
        }
        
        private async void LoadData()
        {
            try
            {
                await _context.Database.EnsureCreatedAsync();
                
                PartnersGrid.ItemsSource = await _context.Partners.ToListAsync();
                MaterialsGrid.ItemsSource = await _context.Materials.Include(m => m.Supplier).ToListAsync();
                ProductsGrid.ItemsSource = await _context.Products.ToListAsync();
                SuppliersGrid.ItemsSource = await _context.Suppliers.ToListAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        // Partner Events
        private void AddPartner_Click(object sender, RoutedEventArgs e)
        {
            var window = new PartnerWindow();
            if (window.ShowDialog() == true)
            {
                LoadData();
            }
        }
        
        private void EditPartner_Click(object sender, RoutedEventArgs e)
        {
            if (PartnersGrid.SelectedItem is Partner partner)
            {
                var window = new PartnerWindow(partner);
                if (window.ShowDialog() == true)
                {
                    LoadData();
                }
            }
        }
        
        private async void DeletePartner_Click(object sender, RoutedEventArgs e)
        {
            if (PartnersGrid.SelectedItem is Partner partner)
            {
                if (MessageBox.Show("Удалить выбранного партнера?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    _context.Partners.Remove(partner);
                    await _context.SaveChangesAsync();
                    LoadData();
                }
            }
        }
        
        // Material Events
        private void AddMaterial_Click(object sender, RoutedEventArgs e)
        {
            var window = new MaterialWindow();
            if (window.ShowDialog() == true)
            {
                LoadData();
            }
        }
        
        private void EditMaterial_Click(object sender, RoutedEventArgs e)
        {
            if (MaterialsGrid.SelectedItem is Material material)
            {
                var window = new MaterialWindow(material);
                if (window.ShowDialog() == true)
                {
                    LoadData();
                }
            }
        }
        
        private async void DeleteMaterial_Click(object sender, RoutedEventArgs e)
        {
            if (MaterialsGrid.SelectedItem is Material material)
            {
                if (MessageBox.Show("Удалить выбранный материал?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    _context.Materials.Remove(material);
                    await _context.SaveChangesAsync();
                    LoadData();
                }
            }
        }
        
        private void ShowMaterialsList_Click(object sender, RoutedEventArgs e)
        {
            var window = new MaterialsListWindow();
            window.ShowDialog();
        }
        
        // Product Events
        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            var window = new ProductWindow();
            if (window.ShowDialog() == true)
            {
                LoadData();
            }
        }
        
        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsGrid.SelectedItem is Product product)
            {
                var window = new ProductWindow(product);
                if (window.ShowDialog() == true)
                {
                    LoadData();
                }
            }
        }
        
        private async void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (ProductsGrid.SelectedItem is Product product)
            {
                if (MessageBox.Show("Удалить выбранный продукт?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    _context.Products.Remove(product);
                    await _context.SaveChangesAsync();
                    LoadData();
                }
            }
        }
        
        // Supplier Events
        private void AddSupplier_Click(object sender, RoutedEventArgs e)
        {
            var window = new SupplierWindow();
            if (window.ShowDialog() == true)
            {
                LoadData();
            }
        }
        
        private void EditSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (SuppliersGrid.SelectedItem is Supplier supplier)
            {
                var window = new SupplierWindow(supplier);
                if (window.ShowDialog() == true)
                {
                    LoadData();
                }
            }
        }
        
        private async void DeleteSupplier_Click(object sender, RoutedEventArgs e)
        {
            if (SuppliersGrid.SelectedItem is Supplier supplier)
            {
                if (MessageBox.Show("Удалить выбранного поставщика?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    _context.Suppliers.Remove(supplier);
                    await _context.SaveChangesAsync();
                    LoadData();
                }
            }
        }
        
        protected override void OnClosed(EventArgs e)
        {
            _context?.Dispose();
            base.OnClosed(e);
        }
    }
}
