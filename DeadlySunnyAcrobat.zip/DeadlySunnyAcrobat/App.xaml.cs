
using System.Windows;

namespace MosaicApp
{
    public partial class App : Application
    {
    }
}
