
using Microsoft.EntityFrameworkCore;
using MosaicApp.Models;

namespace MosaicApp.Data
{
    public class MosaicDbContext : DbContext
    {
        public DbSet<Partner> Partners { get; set; }
        public DbSet<Material> Materials { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Product> Products { get; set; }
        
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=localhost;Database=MosaicDB;Trusted_Connection=true;TrustServerCertificate=true;");
        }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Material>()
                .HasOne(m => m.Supplier)
                .WithMany(s => s.Materials)
                .HasForeignKey(m => m.SupplierId);
        }
    }
}
