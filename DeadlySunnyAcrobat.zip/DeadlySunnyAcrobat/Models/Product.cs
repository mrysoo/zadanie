
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MosaicApp.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string Article { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string ProductType { get; set; }
        
        [Required]
        [MaxLength(200)]
        public string Name { get; set; }
        
        [MaxLength(500)]
        public string Description { get; set; }
        
        public byte[] Image { get; set; }
        
        [Column(TypeName = "decimal(18,2)")]
        public decimal MinimumCost { get; set; }
        
        public double Length { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        
        public double WeightWithoutPackaging { get; set; }
        public double WeightWithPackaging { get; set; }
        
        [MaxLength(100)]
        public string QualityCertificate { get; set; }
        
        [MaxLength(100)]
        public string StandardNumber { get; set; }
        
        public int ProductionTime { get; set; }
        
        [Column(TypeName = "decimal(18,2)")]
        public decimal ProductionCost { get; set; }
        
        public int WorkshopNumber { get; set; }
        public int RequiredPersons { get; set; }
    }
}
