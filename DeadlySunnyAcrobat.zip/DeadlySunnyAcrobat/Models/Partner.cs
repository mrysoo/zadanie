
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MosaicApp.Models
{
    public class Partner
    {
        [Key]
        public int PartnerId { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string PartnerType { get; set; }
        
        [Required]
        [MaxLength(200)]
        public string CompanyName { get; set; }
        
        [Required]
        [MaxLength(300)]
        public string LegalAddress { get; set; }
        
        [Required]
        [MaxLength(12)]
        public string INN { get; set; }
        
        [Required]
        [MaxLength(150)]
        public string DirectorName { get; set; }
        
        [MaxLength(20)]
        public string Phone { get; set; }
        
        [MaxLength(100)]
        public string Email { get; set; }
        
        public byte[] Logo { get; set; }
        
        public int Rating { get; set; }
        
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalSales { get; set; }
        
        [Column(TypeName = "decimal(5,2)")]
        public decimal DiscountPercentage { get; set; }
        
        public DateTime CreatedDate { get; set; }
    }
}
