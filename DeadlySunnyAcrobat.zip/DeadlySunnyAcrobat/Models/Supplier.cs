
using System.ComponentModel.DataAnnotations;

namespace MosaicApp.Models
{
    public class Supplier
    {
        [Key]
        public int SupplierId { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string SupplierType { get; set; }
        
        [Required]
        [MaxLength(200)]
        public string Name { get; set; }
        
        [Required]
        [MaxLength(12)]
        public string INN { get; set; }
        
        public DateTime CreatedDate { get; set; }
        
        public virtual ICollection<Material> Materials { get; set; }
    }
}
