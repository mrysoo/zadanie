
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MosaicApp.Models
{
    public class Material
    {
        [Key]
        public int MaterialId { get; set; }
        
        [Required]
        [MaxLength(100)]
        public string MaterialType { get; set; }
        
        [Required]
        [MaxLength(200)]
        public string Name { get; set; }
        
        [MaxLength(500)]
        public string Description { get; set; }
        
        public byte[] Image { get; set; }
        
        [Column(TypeName = "decimal(18,2)")]
        public decimal Cost { get; set; }
        
        public int QuantityInStock { get; set; }
        
        public int MinimumQuantity { get; set; }
        
        [MaxLength(50)]
        public string UnitOfMeasurement { get; set; }
        
        public int QuantityInPackage { get; set; }
        
        public int SupplierId { get; set; }
        
        [ForeignKey("SupplierId")]
        public virtual Supplier Supplier { get; set; }
    }
}
