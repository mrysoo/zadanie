
using System.Windows;
using MosaicApp.Data;
using MosaicApp.Models;

namespace MosaicApp.Windows
{
    public partial class SupplierWindow : Window
    {
        private Supplier _supplier;
        private bool _isEdit;
        private MosaicDbContext _context;
        
        public SupplierWindow(Supplier supplier = null)
        {
            InitializeComponent();
            _context = new MosaicDbContext();
            _supplier = supplier ?? new Supplier();
            _isEdit = supplier != null;
            
            if (_isEdit)
            {
                LoadSupplierData();
            }
        }
        
        private void LoadSupplierData()
        {
            SupplierTypeTextBox.Text = _supplier.SupplierType;
            NameTextBox.Text = _supplier.Name;
            INNTextBox.Text = _supplier.INN;
        }
        
        private async void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _supplier.SupplierType = SupplierTypeTextBox.Text;
                _supplier.Name = NameTextBox.Text;
                _supplier.INN = INNTextBox.Text;
                
                if (!_isEdit)
                {
                    _supplier.CreatedDate = DateTime.Now;
                    _context.Suppliers.Add(_supplier);
                }
                else
                {
                    _context.Suppliers.Update(_supplier);
                }
                
                await _context.SaveChangesAsync();
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        
        protected override void OnClosed(EventArgs e)
        {
            _context?.Dispose();
            base.OnClosed(e);
        }
    }
}
