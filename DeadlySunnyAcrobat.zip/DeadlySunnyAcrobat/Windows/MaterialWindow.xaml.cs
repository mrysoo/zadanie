
using System.Windows;
using Microsoft.EntityFrameworkCore;
using MosaicApp.Data;
using MosaicApp.Models;

namespace MosaicApp.Windows
{
    public partial class MaterialWindow : Window
    {
        private Material _material;
        private bool _isEdit;
        private MosaicDbContext _context;
        
        public MaterialWindow(Material material = null)
        {
            InitializeComponent();
            _context = new MosaicDbContext();
            _material = material ?? new Material();
            _isEdit = material != null;
            
            LoadSuppliers();
            
            if (_isEdit)
            {
                LoadMaterialData();
            }
        }
        
        private async void LoadSuppliers()
        {
            var suppliers = await _context.Suppliers.ToListAsync();
            SupplierComboBox.ItemsSource = suppliers;
        }
        
        private void LoadMaterialData()
        {
            MaterialTypeTextBox.Text = _material.MaterialType;
            NameTextBox.Text = _material.Name;
            DescriptionTextBox.Text = _material.Description;
            CostTextBox.Text = _material.Cost.ToString();
            QuantityInStockTextBox.Text = _material.QuantityInStock.ToString();
            MinimumQuantityTextBox.Text = _material.MinimumQuantity.ToString();
            UnitOfMeasurementTextBox.Text = _material.UnitOfMeasurement;
            QuantityInPackageTextBox.Text = _material.QuantityInPackage.ToString();
            SupplierComboBox.SelectedValue = _material.SupplierId;
        }
        
        private async void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _material.MaterialType = MaterialTypeTextBox.Text;
                _material.Name = NameTextBox.Text;
                _material.Description = DescriptionTextBox.Text;
                _material.UnitOfMeasurement = UnitOfMeasurementTextBox.Text;
                
                if (decimal.TryParse(CostTextBox.Text, out decimal cost))
                    _material.Cost = cost;
                
                if (int.TryParse(QuantityInStockTextBox.Text, out int stock))
                    _material.QuantityInStock = stock;
                
                if (int.TryParse(MinimumQuantityTextBox.Text, out int min))
                    _material.MinimumQuantity = min;
                
                if (int.TryParse(QuantityInPackageTextBox.Text, out int package))
                    _material.QuantityInPackage = package;
                
                if (SupplierComboBox.SelectedValue != null)
                    _material.SupplierId = (int)SupplierComboBox.SelectedValue;
                
                if (!_isEdit)
                {
                    _context.Materials.Add(_material);
                }
                else
                {
                    _context.Materials.Update(_material);
                }
                
                await _context.SaveChangesAsync();
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        
        protected override void OnClosed(EventArgs e)
        {
            _context?.Dispose();
            base.OnClosed(e);
        }
    }
}
