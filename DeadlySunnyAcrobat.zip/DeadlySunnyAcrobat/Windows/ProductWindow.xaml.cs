
using System.Windows;
using MosaicApp.Data;
using MosaicApp.Models;

namespace MosaicApp.Windows
{
    public partial class ProductWindow : Window
    {
        private Product _product;
        private bool _isEdit;
        private MosaicDbContext _context;
        
        public ProductWindow(Product product = null)
        {
            InitializeComponent();
            _context = new MosaicDbContext();
            _product = product ?? new Product();
            _isEdit = product != null;
            
            if (_isEdit)
            {
                LoadProductData();
            }
        }
        
        private void LoadProductData()
        {
            ArticleTextBox.Text = _product.Article;
            ProductTypeTextBox.Text = _product.ProductType;
            NameTextBox.Text = _product.Name;
            DescriptionTextBox.Text = _product.Description;
            MinimumCostTextBox.Text = _product.MinimumCost.ToString();
            LengthTextBox.Text = _product.Length.ToString();
            WidthTextBox.Text = _product.Width.ToString();
            HeightTextBox.Text = _product.Height.ToString();
            WeightWithoutPackagingTextBox.Text = _product.WeightWithoutPackaging.ToString();
            WeightWithPackagingTextBox.Text = _product.WeightWithPackaging.ToString();
            QualityCertificateTextBox.Text = _product.QualityCertificate;
            StandardNumberTextBox.Text = _product.StandardNumber;
            ProductionTimeTextBox.Text = _product.ProductionTime.ToString();
            ProductionCostTextBox.Text = _product.ProductionCost.ToString();
            WorkshopNumberTextBox.Text = _product.WorkshopNumber.ToString();
            RequiredPersonsTextBox.Text = _product.RequiredPersons.ToString();
        }
        
        private async void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _product.Article = ArticleTextBox.Text;
                _product.ProductType = ProductTypeTextBox.Text;
                _product.Name = NameTextBox.Text;
                _product.Description = DescriptionTextBox.Text;
                _product.QualityCertificate = QualityCertificateTextBox.Text;
                _product.StandardNumber = StandardNumberTextBox.Text;
                
                if (decimal.TryParse(MinimumCostTextBox.Text, out decimal minCost))
                    _product.MinimumCost = minCost;
                
                if (double.TryParse(LengthTextBox.Text, out double length))
                    _product.Length = length;
                
                if (double.TryParse(WidthTextBox.Text, out double width))
                    _product.Width = width;
                
                if (double.TryParse(HeightTextBox.Text, out double height))
                    _product.Height = height;
                
                if (double.TryParse(WeightWithoutPackagingTextBox.Text, out double weightWo))
                    _product.WeightWithoutPackaging = weightWo;
                
                if (double.TryParse(WeightWithPackagingTextBox.Text, out double weightW))
                    _product.WeightWithPackaging = weightW;
                
                if (int.TryParse(ProductionTimeTextBox.Text, out int prodTime))
                    _product.ProductionTime = prodTime;
                
                if (decimal.TryParse(ProductionCostTextBox.Text, out decimal prodCost))
                    _product.ProductionCost = prodCost;
                
                if (int.TryParse(WorkshopNumberTextBox.Text, out int workshop))
                    _product.WorkshopNumber = workshop;
                
                if (int.TryParse(RequiredPersonsTextBox.Text, out int persons))
                    _product.RequiredPersons = persons;
                
                if (!_isEdit)
                {
                    _context.Products.Add(_product);
                }
                else
                {
                    _context.Products.Update(_product);
                }
                
                await _context.SaveChangesAsync();
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        
        protected override void OnClosed(EventArgs e)
        {
            _context?.Dispose();
            base.OnClosed(e);
        }
    }
}
