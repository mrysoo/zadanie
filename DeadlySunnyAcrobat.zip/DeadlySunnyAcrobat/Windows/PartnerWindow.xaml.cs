
using System.Windows;
using MosaicApp.Data;
using MosaicApp.Models;

namespace MosaicApp.Windows
{
    public partial class PartnerWindow : Window
    {
        private Partner _partner;
        private bool _isEdit;
        private MosaicDbContext _context;
        
        public PartnerWindow(Partner partner = null)
        {
            InitializeComponent();
            _context = new MosaicDbContext();
            _partner = partner ?? new Partner();
            _isEdit = partner != null;
            
            if (_isEdit)
            {
                LoadPartnerData();
            }
        }
        
        private void LoadPartnerData()
        {
            PartnerTypeTextBox.Text = _partner.PartnerType;
            CompanyNameTextBox.Text = _partner.CompanyName;
            LegalAddressTextBox.Text = _partner.LegalAddress;
            INNTextBox.Text = _partner.INN;
            DirectorNameTextBox.Text = _partner.DirectorName;
            PhoneTextBox.Text = _partner.Phone;
            EmailTextBox.Text = _partner.Email;
            RatingTextBox.Text = _partner.Rating.ToString();
            DiscountTextBox.Text = _partner.DiscountPercentage.ToString();
        }
        
        private async void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _partner.PartnerType = PartnerTypeTextBox.Text;
                _partner.CompanyName = CompanyNameTextBox.Text;
                _partner.LegalAddress = LegalAddressTextBox.Text;
                _partner.INN = INNTextBox.Text;
                _partner.DirectorName = DirectorNameTextBox.Text;
                _partner.Phone = PhoneTextBox.Text;
                _partner.Email = EmailTextBox.Text;
                
                if (int.TryParse(RatingTextBox.Text, out int rating))
                    _partner.Rating = rating;
                
                if (decimal.TryParse(DiscountTextBox.Text, out decimal discount))
                    _partner.DiscountPercentage = discount;
                
                if (!_isEdit)
                {
                    _partner.CreatedDate = DateTime.Now;
                    _context.Partners.Add(_partner);
                }
                else
                {
                    _context.Partners.Update(_partner);
                }
                
                await _context.SaveChangesAsync();
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
        
        protected override void OnClosed(EventArgs e)
        {
            _context?.Dispose();
            base.OnClosed(e);
        }
    }
}
