
using System.Windows;
using Microsoft.EntityFrameworkCore;
using MosaicApp.Data;
using MosaicApp.Models;

namespace MosaicApp.Windows
{
    public partial class MaterialsListWindow : Window
    {
        private MosaicDbContext _context;
        
        public MaterialsListWindow()
        {
            InitializeComponent();
            _context = new MosaicDbContext();
            LoadMaterials();
        }
        
        private async void LoadMaterials()
        {
            try
            {
                var materials = await _context.Materials
                    .Include(m => m.Supplier)
                    .Select(m => new MaterialDisplayModel
                    {
                        MaterialType = m.MaterialType,
                        Name = m.Name,
                        MinimumQuantity = m.MinimumQuantity,
                        QuantityInStock = m.QuantityInStock,
                        UnitOfMeasurement = m.UnitOfMeasurement,
                        Cost = m.Cost,
                        BatchCost = m.Cost * m.QuantityInPackage
                    })
                    .ToListAsync();
                
                MaterialsItemsControl.ItemsSource = materials;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки материалов: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        protected override void OnClosed(EventArgs e)
        {
            _context?.Dispose();
            base.OnClosed(e);
        }
    }
    
    public class MaterialDisplayModel
    {
        public string MaterialType { get; set; }
        public string Name { get; set; }
        public int MinimumQuantity { get; set; }
        public int QuantityInStock { get; set; }
        public string UnitOfMeasurement { get; set; }
        public decimal Cost { get; set; }
        public decimal BatchCost { get; set; }
    }
}
